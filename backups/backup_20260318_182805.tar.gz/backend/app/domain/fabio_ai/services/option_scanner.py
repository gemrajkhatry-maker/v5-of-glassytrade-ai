"""OptionScannerService — Simple momentum-based contract selection.

Selects contracts based on:
1. Momentum direction (CE for bullish, PE for bearish)
2. Basic liquidity (OI, volume)
3. ATM proximity (gamma optimization)

No complex scoring — just follow the momentum with liquid contracts.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ScanResult:
    symbol: str
    underlying: str
    strike: int
    option_type: str  # "CE" or "PE"
    expiry: str
    ltp: float
    oi: int
    volume: int
    spread: float
    score: float = 0.0
    bias: str = ""  # "BULLISH" | "BEARISH" | "NEUTRAL"
    bias_reason: str = ""
    delta: float = 0.0
    iv: float = 0.0


class OptionScannerService:
    """Simple momentum-based contract selection for MCX/NSE."""

    _STRIKE_INTERVALS = {
        "NIFTY": 50, "BANKNIFTY": 100, "FINNIFTY": 50,
        "CRUDEOIL": 50, "NATURALGAS": 5, "GOLD": 100, "SILVER": 500
    }
    
    _MIN_OI = {
        "NIFTY": 500_000, "BANKNIFTY": 300_000, "FINNIFTY": 50_000,
        "CRUDEOIL": 5_000, "NATURALGAS": 5_000, "GOLD": 1_000, "SILVER": 1_000
    }

    def __init__(self, broker) -> None:
        self._broker = broker
        self._ib_high = 0.0
        self._ib_low = 0.0
        self._session_vwap = 0.0
        self._session_poc = 0.0

    def scan_top_n(
        self,
        n: int = 3,
        underlyings: list[str] | None = None,
        preferred_option_type: str | None = None,
        top_per_underlying: int = 3,
        exchange: str | None = None,
        expiry_index: int = 0,
        strikes_around_atm: int = 2,
    ) -> list[ScanResult]:
        """Select top N contracts based on momentum and liquidity."""
        from app.config import settings
        
        # Exchange mapping per underlying
        _NSE_UNDERLYINGS = {"NIFTY", "BANKNIFTY", "FINNIFTY"}
        _MCX_UNDERLYINGS = {"CRUDEOIL", "NATURALGAS", "GOLD", "SILVER"}
        
        results = []
        
        # Use config underlyings if not specified
        if underlyings is None:
            config_unds = settings.SCANNER_UNDERLYINGS
            underlyings = [u.strip() for u in config_unds.split(",")] if isinstance(config_unds, str) else list(config_unds)
        
        for u in underlyings:
            try:
                # Auto-detect exchange from underlying
                if u.upper() in _MCX_UNDERLYINGS:
                    _exchange = "MCX"
                elif u.upper() in _NSE_UNDERLYINGS:
                    _exchange = "NFO"
                else:
                    _exchange = exchange or settings.DEFAULT_EXCHANGE
                
                chain = self._broker.get_option_chain(
                    underlying=u,
                    exchange=_exchange,
                    expiry_index=expiry_index,
                )
                if chain is None:
                    continue

                atm = chain.atm_strike
                interval = self._STRIKE_INTERVALS.get(u.upper(), 50)
                
                # Detect momentum (for logging/sorting, not filtering)
                bias, bias_strength, bias_reason = self._detect_momentum(chain, atm, interval)
                logger.info("MOMENTUM: %s — %s (strength=%d)", u, bias, bias_strength)
                
                # Scan BOTH CE and PE contracts near ATM
                # LLM decides direction based on full market context
                strikes = [atm + i * interval for i in range(-strikes_around_atm, strikes_around_atm + 1)]
                
                # Process both CE and PE
                for opt_type, option_map in [("CE", chain.calls), ("PE", chain.puts)]:
                    for strike in strikes:
                        opt = option_map.get(float(strike))
                    if opt is None:
                        continue
                    
                    ltp = float(opt.ltp or 0)
                    if ltp <= 0:
                        continue
                    
                    oi = int(opt.oi or 0)
                    vol = int(opt.volume or 0)
                    
                    # Hard filters
                    min_oi = self._MIN_OI.get(u.upper(), 5000)
                    if oi < min_oi:
                        continue
                    
                    bid = float(opt.bid or 0)
                    ask = float(opt.ask or 0)
                    if bid > 0 and ask > 0 and ltp > 0:
                        spread_pct = (ask - bid) / ltp * 100
                        if spread_pct > 2.5:
                            continue
                    
                    # Simple scoring: ATM proximity + OI + Volume
                    atm_dist = abs(strike - atm) / interval if interval > 0 else 0
                    delta_val = abs(float(opt.delta or 0.5))
                    
                    score = 0
                    # ATM proximity (40 pts)
                    score += max(0, 40 - (atm_dist * 15))
                    # OI (30 pts)
                    score += min(30, (oi / min_oi) * 10)
                    # Volume (20 pts)  
                    score += min(20, (vol / 1000) * 5)
                    # Delta sweet spot (10 pts)
                    if 0.40 <= delta_val <= 0.60:
                        score += 10
                    
                    results.append(ScanResult(
                        symbol=opt.symbol,
                        underlying=u,
                        strike=int(strike),
                        option_type=opt_type,
                        expiry=chain.expiry.date().isoformat(),
                        ltp=ltp, oi=oi, volume=vol,
                        spread=ask - bid if bid > 0 and ask > 0 else 0,
                        score=score, bias=bias, bias_reason=bias_reason,
                        delta=delta_val,
                        iv=float(opt.iv or 0) if hasattr(opt, 'iv') else 0,
                    ))

            except Exception as e:
                logger.error("scan_top_n failed for %s: %s", u, e)
        
        # Sort by score, return top N
        results.sort(key=lambda r: -r.score)
        final = results[:n]
        
        # If no contracts found (no momentum), return ATM contracts for monitoring
        if not final:
            logger.info("No momentum setups — selecting ATM contracts for monitoring")
            for u in (underlyings or ["CRUDEOIL", "NATURALGAS"]):
                try:
                    chain = self._broker.get_option_chain(
                        underlying=u, exchange=exchange or "MCX", expiry_index=expiry_index,
                    )
                    if chain is None:
                        continue
                    atm = chain.atm_strike
                    # Get ATM CE for display
                    atm_ce = chain.calls.get(float(atm))
                    if atm_ce and float(atm_ce.ltp or 0) > 0:
                        final.append(ScanResult(
                            symbol=atm_ce.symbol,
                            underlying=u,
                            strike=int(atm),
                            option_type=opt_type,
                            expiry=chain.expiry.date().isoformat() if hasattr(chain.expiry, 'date') else "",
                            ltp=float(atm_ce.ltp),
                            oi=int(atm_ce.oi or 0),
                            volume=int(atm_ce.volume or 0),
                            spread=float(atm_ce.ask or 0) - float(atm_ce.bid or 0),
                            score=50,  # Neutral score
                            bias="NEUTRAL",
                            bias_reason="No momentum — monitoring ATM",
                            delta=float(atm_ce.delta or 0.5),
                            iv=float(atm_ce.iv or 0),
                        ))
                        break
                except Exception:
                    continue
        
        logger.info("scan_top_n: %d contracts found, returning %d", len(results) + len(final), len(final))
        for i, r in enumerate(final, 1):
            logger.info("  #%d %s Strike=%d LTP=%.2f Score=%.0f",
                        i, r.symbol, r.strike, r.ltp, r.score)
        
        return final

    def _detect_momentum(self, chain, atm, interval):
        """Simple momentum detection from option chain."""
        # CE vs PE volume ratio near ATM
        ce_vol = sum(int(o.volume or 0) for o in chain.calls.values())
        pe_vol = sum(int(o.volume or 0) for o in chain.puts.values())
        
        if ce_vol > pe_vol * 1.5:
            return "BULLISH", 3, f"CE volume {ce_vol} > PE volume {pe_vol}"
        elif pe_vol > ce_vol * 1.5:
            return "BEARISH", 3, f"PE volume {pe_vol} > CE volume {ce_vol}"
        else:
            return "NEUTRAL", 0, f"Balanced CE={ce_vol} PE={pe_vol}"

    def update_market_context(self, ib_high, ib_low, vwap, session_poc):
        """Update context for scoring."""
        self._ib_high = ib_high
        self._ib_low = ib_low
        self._session_vwap = vwap
        self._session_poc = session_poc


class ContractSwitchGuard:
    """Prevents switching contracts during open trades."""
    
    def __init__(self):
        self._current_contract = None
        self._current_score = 0.0
        self._last_score_time = 0.0
        self._has_open_trade = False
    
    def set_open_trade(self, has_trade: bool):
        self._has_open_trade = has_trade
    
    def should_switch(self, new_contract, new_score, current_time):
        if self._has_open_trade:
            return False  # NEVER switch during open trade
        if self._current_contract is None:
            self._current_contract = new_contract
            self._current_score = new_score
            self._last_score_time = current_time
            return True
        if new_contract == self._current_contract:
            return False
        if current_time - self._last_score_time < 300:  # 5 min cooldown
            return False
        # Switch only if score delta > 15 pts
        if abs(new_score - self._current_score) > 15:
            self._current_contract = new_contract
            self._current_score = new_score
            self._last_score_time = current_time
            return True
        return False
